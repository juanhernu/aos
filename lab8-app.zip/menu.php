<nav class="navbar navbar-default" role="navigation">

<div class="navbar-header">
  <a class="navbar-brand" href="/"><img height="25" src="logo.png" /></a>
</div>

</nav>
