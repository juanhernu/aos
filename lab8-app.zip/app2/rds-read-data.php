<h2>Address Book</h2><p>
<?php
  //This is a simple address book example for testing with RDS

  include('rds.conf.php');

  
// Conectar a la base de datos usando mysqli
$conn = mysqli_connect($RDS_URL, $RDS_user, $RDS_pwd, $RDS_DB) or die(mysqli_error($conn));
mysqli_set_charset($conn, "utf8mb4");

// Manejar modos
if ($mode == "add") {
    // Código para mostrar el formulario de agregar
} elseif ($mode == "added") {
    $stmt = $conn->prepare("INSERT INTO address (lastname, firstname, phone, email) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $lastname, $firstname, $phone, $email);
    $stmt->execute();
    $stmt->close();
    echo "Contacto agregado correctamente.";
} elseif ($mode == "edit") {
    // Código para mostrar el formulario de edición
} elseif ($mode == "edited") {
    $stmt = $conn->prepare("UPDATE address SET lastname = ?, firstname = ?, phone = ?, email = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $lastname, $firstname, $phone, $email, $id);
    $stmt->execute();
    $stmt->close();
    echo "Contacto actualizado correctamente.";
} elseif ($mode == "remove") {
    $stmt = $conn->prepare("DELETE FROM address WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    echo "Contacto eliminado.";
}

// Mostrar contactos
$data = mysqli_query($conn, "SELECT * FROM address ORDER BY lastname ASC") or die(mysqli_error($conn));
while ($info = mysqli_fetch_array($data)) {
    // Código para mostrar cada contacto
}

mysqli_close($conn);
?>
